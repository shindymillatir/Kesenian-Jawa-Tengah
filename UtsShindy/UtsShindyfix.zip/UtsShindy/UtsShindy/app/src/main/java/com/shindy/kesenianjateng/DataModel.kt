package id.ac.utsshindy

data class DataModel (
    val gambar: Int,
    val harga: String,
    val nama:String,
    val keterangan:String
)